var config = {
    mode: "fixed_servers",
    rules: {
      singleProxy: {
        scheme: "http",
        host: "172.25.135.187",
        port: parseInt("61888")
      },
      bypassList: ["foobar.com"]
    }
  };
 
chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
 
function callbackFn(details) {
    return {
        authCredentials: {
            username: "jdjr_crawler",
            password: "jdjr_crawler007"
        }
    };
}
 
chrome.webRequest.onAuthRequired.addListener(
        callbackFn,
        {urls: ["<all_urls>"]},
        ['blocking']
);